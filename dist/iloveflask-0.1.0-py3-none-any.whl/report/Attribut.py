        
class Attribut:
    name = ""
    desc = ""
    def __init__(self, name, desc):
        self.name = name
        self.desc = desc